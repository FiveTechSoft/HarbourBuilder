/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2602281433lu
#define HB_VER_CHLID             "8459535e8efb0ec10aa895734fd2d8682532cb90"
#define HB_VER_LENTRY            "2026-02-28 15:33 UTC+0100 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_CFLAGS    "--target=aarch64-linux-android24 -fPIC "
#define HB_VER_HB_USER_LDFLAGS   "--target=aarch64-linux-android24"
#define HB_PLATFORM              "android"
#define HB_COMPILER              "clang"
